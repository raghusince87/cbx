import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public cities = [];
  constructor(
    private router: Router,
  ) { }

  ngOnInit(): void {
    //adding cities to cities array
    this.cities = [
      {
        id: "1",
        name: "London",
        temperature: "17 °C",
        sunriseTime: "6:00",
        sunsetTime: "18:34"
      },
      {
        id: "2",
        name: "Birmingham",
        temperature: "19 °C",
        sunriseTime: "7:45",
        sunsetTime: "19:57"
      },
      {
        id: "3",
        name: "Liverpool",
        temperature: "10 °C",
        sunriseTime: "4:53",
        sunsetTime: "20:52"
      },
      {
        id: "4",
        name: "Manchester",
        temperature: "14 °C",
        sunriseTime: "6:15",
        sunsetTime: "17:49"
      },
      {
        id: "5",
        name: "Nottingham",
        temperature: "16 °C",
        sunriseTime: "7:53",
        sunsetTime: "18:05"
      }
    ]
  }
  //city click function, It will redirects to forecat page
  cityClick(name) {
    this.router.navigate(["/forecast"], { queryParams: { cityname: name } });
  }
}
