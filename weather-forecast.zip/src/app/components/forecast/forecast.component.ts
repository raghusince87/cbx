import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WeatherService } from 'src/app/services/weather.service';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.css']
})
export class ForecastComponent implements OnInit {
  city: string;
  weatherData: any;
  constructor(
    private _route: ActivatedRoute,
    public _router: Router,
    private _service: WeatherService,
  ) {
    //accessing city query pa parameter
    this._route.queryParams.subscribe((params) => {
      if (params["cityname"] != undefined) {
        this.city = params["cityname"];
      }
    });
  }

  ngOnInit(): void {
    this.getWeatherForecatByCityName();
  }
  getWeatherForecatByCityName() {
    // calling service method to get selected city weather data
    this._service
      .getWeatherForecatByCityName(this.city)
      .subscribe((response: any) => {
        this.weatherData = response;
        //filtering  coming 5days at 9 am records:
        this.weatherData = this.weatherData.list.filter(x => x.dt_txt.split(' ')[1] == "09:00:00");
        console.log("weather forecast for coming 5 days at 9 am :", this.weatherData);
      });
  }

  home() {
    //redirecting to home page
    this._router.navigate(["/"]);
  }
}
