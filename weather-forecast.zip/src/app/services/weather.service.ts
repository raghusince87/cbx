import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(
    private http: HttpClient
  ) { }

  getWeatherForecatByCityName(city) {
    //const url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + ",uk&appid=3d8b309701a13f65b660fa2c64cdc517";
    const url = "https://api.openweathermap.org/data/2.5/forecast?q=" + city + ",uk&appid=3d8b309701a13f65b660fa2c64cdc517"
    var getHeaders = {
      headers: new HttpHeaders().set(
        "Content-Type",
        "application/x-www-form-urlencoded"
      ),

    };
    return this.http.get(url, getHeaders);
  }
}
